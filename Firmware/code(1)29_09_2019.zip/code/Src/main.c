/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2019 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_hal.h"

/* USER CODE BEGIN Includes */
#include "P5.h"
#include "flash.h"
#include "IR.h"
#include "amlich.h"
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
#define DELETE 9999
char ef_time=0;
char gio_auto;
char AUTO_EF;

uint16_t String_read(int add);
void String_SaveData(void);
void manhinhchinh(int mode,char inphut);

unsigned char mauchuChay[3]={0,31,0};

unsigned char font_number=0,font_number2; // ADD=40
char mode_hienthi=0;         // ADD=41
struct
{
	unsigned char Hours[3];
	unsigned char Minute[3];
	unsigned char Seconds[3];
	unsigned char Day[3];
	unsigned char Date[3];
	unsigned char Month[3];
	unsigned char Year[3];
	unsigned char ND[3];
}CoLor;
void Color_init()
{

  unsigned char *c = CoLor.Hours;
	if(EEP_read(6) != 1)
	{
		EEP_write(6,1);
		//khoi tao mau sac
		c[0]=31;c[1]=0;c[2]=0;
		c[3]=0;c[4]=31;c[5]=0;
		c[6]=0;c[7]=0;c[8]=31;
		c[9]=0;c[10]=31;c[11]=31;
		c[12]=31;c[13]=31;c[14]=0;
		c[15]=31;c[16]=0;c[17]=31;
		c[18]=31;c[19]=31;c[20]=31;
		c[21]=31;c[22]=0;c[23]=0;
		for(int i=7;i<31;i++)EEP_write(i,c[i-7]);
		EEP_write(40,0); //F1
		EEP_write(41,0);
		EEP_write(42,100); //dosang
		EEP_write(43,0); //R
		EEP_write(44,31); //G
		EEP_write(45,0); //B
		EEP_write(46,0); //F2
		EEP_write(47,22); 
		EEP_write(48,1); 
		P5_SetStringRun(S{67,108,111,99,107,32,77,97,116,114,105,120,32,76,69,68,32,112,52,53,32,100,101,115,105,103,110,32,66,121,32,68,97,111,78,103,117,121,101,110,32,45,32,83,68,84,58,48,51,57,52,55,51,51,51,49,49,32,32,32,32,32,32,32,32,32,32,32,0});
		String_SaveData();	   			
	}
	for(int i=7;i<31;i++)c[i-7] = EEP_read(i);
	font_number = EEP_read(40);
	mode_hienthi = EEP_read(41);
	SET_dosang(EEP_read(42));	
	for(int i=0;i<128;i++)String_runSetTxt(i,String_read(i));
	mauchuChay[0]=EEP_read(43);
	mauchuChay[1]=EEP_read(44);
	mauchuChay[2]=EEP_read(45);
	font_number2=EEP_read(46);
	gio_auto=EEP_read(47);
	AUTO_EF=EEP_read(48);
	String_runSetALLColor(mauchuChay[0],mauchuChay[1],mauchuChay[2]);
}
//-----------------------Khai bao nguyen mau ham--------------------------------//
void manhinhchinh(int mode,char inphut);

//----------------------Phan giao tiep i2c-thoi gian thuc ---------------------//
unsigned char i2c_write[1];
char time[7],giaycu,ngay_al,thang_al,nhietdo;
unsigned char i2c_rv[18];
void BCD_Decoder()
{
	for(char x=0;x<7;x++) time[x]=(i2c_rv[x] & 0x0f) + (i2c_rv[x]>>4)*10;
}
unsigned char BCD_Encoder(unsigned char temp)
{
	return ((temp/10)<<4)|(temp%10);
}
void laythoigian()
{
	HAL_I2C_Mem_Read(&hi2c1,0x68<<1,0,I2C_MEMADD_SIZE_8BIT,i2c_rv,18,1000); //read time
	BCD_Decoder(); //chuyen doi
	nhietdo = i2c_rv[17];
}
void ghids(unsigned char add, unsigned char dat)
{
	i2c_write[0] = BCD_Encoder(dat);
	HAL_I2C_Mem_Write(&hi2c1,0x68<<1,add,I2C_MEMADD_SIZE_8BIT,i2c_write,1,1000); 
}
//----------------------------------------END------------------------------------------//
void Key_hoclenh()
{
	if(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_4) == GPIO_PIN_RESET) //neu nut hoc lenh dc click
		{
			HAL_Delay(20);
			while(HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_4) == GPIO_PIN_RESET); //cho nha nut nhan
			P5_outtro(0);
			P5_chonvitri(0,0);
			P5_sendString_wColor(S{67,104,187,32,180,207,0},31,0,31);
			P5_chonvitri(0,16);
			P5_sendString_wColor(S{104,201,99,32,108,191,110,104,0},31,0,31);
			HAL_Delay(1500);
			P5_outtro(1);
			SET_chedohoclenh(1);
			//clear tat ca data cua phim cu di
			for(int i=0;i<6;i++) SET_KEY_IR(i,0);
			P5_chonvitri(0,0);
			P5_sendString_wColor(S{84,168,110,103,32,180,207,0},0,31,0); //tang do sang
			P5_chonvitri(0,16);
			P5_sendString_wColor(S{115,163,110,103,0},0,31,0); //tang do sang
			while(GET_chedohoclenh() != 0){;}
      for(int i=0;i<6;i++) EEP_write(i,GET_KEY_IR(i));
			P5_outtro(0);
			manhinhchinh(mode_hienthi,1);
		}
}
//-----Chuong trinh cai dat thoi gian, mau sac ...  -----//
void in_tenLen(char c)
{
	char CoLor[3];
	if(c==0){CoLor[0]=31;CoLor[1]=31;CoLor[2]=31;}
	else {CoLor[0]=31;CoLor[1]=0;CoLor[2]=0;}
	set_px(59,16,CoLor[0],CoLor[1],CoLor[2]);
  P5_veduongthang(58,17,60,17,CoLor[0],CoLor[1],CoLor[2]);
  P5_veduongthang(57,18,61,18,CoLor[0],CoLor[1],CoLor[2]);
}
void in_tenXuong(char c)
{
	char CoLor[3];
	if(c==0){CoLor[0]=31;CoLor[1]=31;CoLor[2]=31;}
	else {CoLor[0]=0;CoLor[1]=31;CoLor[2]=0;}
	P5_veduongthang(57,25,61,25,CoLor[0],CoLor[1],CoLor[2]);
  P5_veduongthang(58,26,60,26,CoLor[0],CoLor[1],CoLor[2]);
	set_px(59,27,CoLor[0],CoLor[1],CoLor[2]);
}
void in_OK(char c)
{
	char CoLor[3];
	if(c==0){CoLor[0]=31;CoLor[1]=31;CoLor[2]=31;}
	else {CoLor[0]=0;CoLor[1]=0;CoLor[2]=31;}
	P5_veduongthang(57,20,61,20,CoLor[0],CoLor[1],CoLor[2]);
  P5_veduongthang(57,21,61,21,CoLor[0],CoLor[1],CoLor[2]);
	P5_veduongthang(57,22,61,22,CoLor[0],CoLor[1],CoLor[2]);
	P5_veduongthang(57,23,61,23,CoLor[0],CoLor[1],CoLor[2]);
}

char caiTime(char so,unsigned char *s,char max,char min,char cR,char cG,char cB)
{
	unsigned long t=HAL_GetTick();
	int key;
	P5_clear();
	P5_chonvitri(0,0);
	P5_sendString_wColor(s,cR,cG,cB);	
	P5_chonvitri(0,16);
	if (max==7){if(so==1)P5_sendString((unsigned char *)"CN ");else P5_sendtext(so+48);}
	else if(max!=99){P5_sendtext(so/10+48);P5_sendtext(so%10+48);P5_sendtext(' ');}
	else {P5_sendString((unsigned char *)"20");P5_sendtext(so/10+48);P5_sendtext(so%10+48);P5_sendtext(' ');}
	in_tenLen(0);in_tenXuong(0);in_OK(0);		
	Set_color(31,31,31);
	HAL_Delay(300);SET_key(0);
  while(1)
  {
		if(HAL_GetTick() - t > 200){in_tenLen(0);in_tenXuong(0);t=HAL_GetTick();}
		key=GET_key();
		if(key==3)//nhan nut OK
		{
			HAL_Delay(300);
			SET_key(0);
			return so;
		}
		else if(key==1)//nut UP
		{
			in_tenXuong(0);in_tenLen(1);
			so++;if(so>max)so=min;
			P5_chonvitri(0,16);
			if (max==7){if(so==1)P5_sendString((unsigned char *)"CN ");else P5_sendtext(so+48);P5_sendString((unsigned char *)"    ");}
			else if(max!=99){P5_sendtext(so/10+48);P5_sendtext(so%10+48);P5_sendtext(' ');}
			else {P5_sendString((unsigned char *)"20");P5_sendtext(so/10+48);P5_sendtext(so%10+48);P5_sendtext(' ');}
			t=HAL_GetTick();
			HAL_Delay(100);SET_key(0);
		}
		else if(key==2)//nut DOWN
		{
			in_tenXuong(1);in_tenLen(0);
			if(so==min)so=max;else so--;
			P5_chonvitri(0,16);
			if (max==7){if(so==1)P5_sendString((unsigned char *)"CN ");else P5_sendtext(so+48);P5_sendString((unsigned char *)"    ");}
			else if(max!=99){P5_sendtext(so/10+48);P5_sendtext(so%10+48);P5_sendtext(' ');}
			else {P5_sendString((unsigned char *)"20");P5_sendtext(so/10+48);P5_sendtext(so%10+48);P5_sendtext(' ');}
			t=HAL_GetTick();
			HAL_Delay(100);SET_key(0);
		}
  }		
}
char caiColor(unsigned char *s,unsigned char *c,char special)
{
	unsigned long t=HAL_GetTick();
	int caid=0,nhay=0;
	int key;
	P5_clear();
	P5_chonvitri(0,0);
  P5_sendString_wColor(s,c[0],c[1],c[2]);	
	P5_vehinhchunhat_Vien(1,19,7,5,c[0],0,0);
	P5_vehinhchunhat_Vien(9,19,7,5,0,c[1],0);
	P5_vehinhchunhat_Vien(17,19,7,5,0,0,c[2]);
	in_tenLen(0);in_tenXuong(0);in_OK(0);		
	if(special)P5_special(0);
	HAL_Delay(300);SET_key(0);
	while(1)
	{
		if(HAL_GetTick() - t > 200)
      {
				in_tenLen(0);in_tenXuong(0);in_OK(0);	
				nhay=1-nhay;
				if(nhay)
				{
					     if(caid==0)P5_vehinhchunhat(1,19,7,5,31,31,31);
					else if(caid==1)P5_vehinhchunhat(9,19,7,5,31,31,31);
					else if(caid==2)P5_vehinhchunhat(17,19,7,5,31,31,31);
					else if(caid==3)P5_special(0);
				}
				else
				{
					     if(caid==0)P5_vehinhchunhat(1,19,7,5,0,0,0);
					else if(caid==1)P5_vehinhchunhat(9,19,7,5,0,0,0);
					else if(caid==2)P5_vehinhchunhat(17,19,7,5,0,0,0);
					else if(caid==3)P5_special(1);
				}
			  t=HAL_GetTick();
			}
		key=GET_key();
		if(key==2 || key==1)//nhan nut tang do sang
		{			
		  if(caid<3)
				{
					if(key==1){in_tenLen(1);c[caid]++;if(c[caid]>31)c[caid]=31;}
					else {in_tenXuong(1);if(c[caid]==0)c[caid]=0;else c[caid]--;}
					P5_vehinhchunhat_Vien(1,19,7,5,c[0],0,0);P5_vehinhchunhat_Vien(9,19,7,5,0,c[1],0);P5_vehinhchunhat_Vien(17,19,7,5,0,0,c[2]);
					P5_chonvitri(0,0);
					P5_sendString_wColor(s,c[0],c[1],c[2]);	
				}
			SET_key(0);
		}
		else if(key==5) //UP
		{
			P5_vehinhchunhat(1,19,7,5,31,31,31);P5_vehinhchunhat(9,19,7,5,31,31,31);P5_vehinhchunhat(17,19,7,5,31,31,31);
			caid++; if(caid>2+special)caid=0; 
			HAL_Delay(300);SET_key(0);
		}
		else if(key==4) //DOWN
		{
			P5_vehinhchunhat(1,19,7,5,31,31,31);P5_vehinhchunhat(9,19,7,5,31,31,31);P5_vehinhchunhat(17,19,7,5,31,31,31);
			caid--;if(caid<0)caid=2+special;
			HAL_Delay(300);SET_key(0);
		}
		else if(key==6) //thoat
		{
			return 1;
		}
		else if(key==3) //OK - thoat
		{
			if(caid!=3)return 0;
			else
			{
				P5_outtro(0);
				signed int dem_special=0;
				Set_color(255-dem_special,CoLor.Hours[1],CoLor.Hours[2]);
				P5_sendnumber_font1(0,0,time[2]/10,font_number);
		    P5_sendnumber_font1(14,0,time[2]%10,font_number);
				in_tenLen(0);in_tenXuong(0);in_OK(0);					
				SET_key(0);
				while(1)
				{
					key=GET_key();
					if(key ==1 || key==2)
					{
						if(key==1){dem_special++;if(dem_special==8)dem_special=0;in_tenLen(1);}
						if(key==2){dem_special--;if(dem_special<0)dem_special=7;in_tenXuong(1);}
						Set_color(255-dem_special,CoLor.Hours[1],CoLor.Hours[2]);
				    P5_sendnumber_font1(0,0,time[2]/10,font_number);
		        P5_sendnumber_font1(14,0,time[2]%10,font_number);
						HAL_Delay(300);SET_key(0);
						in_tenLen(0);in_tenXuong(0);in_OK(0);
					}
					else if(key==3)
					{
						 c[0] = 255-dem_special;
						 return 0;
					}
				}
			}
		}
	}
}


////////////////////////////////////////////////////////////////////////////////////////////////////
#define DATA_START_ADDRESS2 		 	((uint32_t)0x0801F800)	//Page 126
uint16_t String_read(int add)
{
	int32_t addr;
	addr = DATA_START_ADDRESS2 + (add*2);
	uint16_t* val = (uint16_t *)addr;
	return *val;
}
void String_SaveData(void)
{
	uint32_t addr;
	Flash_Erase(DATA_START_ADDRESS2);
	Flash_Unlock();
	for(int i=0;i<128;i++)
	{
		addr = DATA_START_ADDRESS2 + (i*2);
		FLASH->CR |= FLASH_CR_PG;				/*!< Programming */
		while((FLASH->SR&FLASH_SR_BSY)){;}
    *(__IO uint16_t*)addr = (uint16_t)P5_GetStringRun(i);
		while((FLASH->SR&FLASH_SR_BSY));
		FLASH->CR &= ~FLASH_CR_PG;
	}
	Flash_Lock();
}
void caiChuChay()
{
	unsigned char key;
	unsigned long timenhay;
	int chu=0;
	char kt=0;
	P5_clear();
	in_tenLen(0);in_tenXuong(0);in_OK(0);	
	HAL_Delay(200);SET_key(0);
	while(1)
	{
			if(HAL_GetTick() - timenhay > 200) // nhap nhay chu can cai dat
			{
				kt=1-kt;
				P5_chonvitri(0,0);
				if(kt)P5_sendString_wColorRun(chu,1);
				else P5_sendString_wColorRun(chu,0);
				in_tenLen(0);in_tenXuong(0);in_OK(0);
				timenhay=HAL_GetTick();
			}
			key=GET_key();
			if(key==1)
			{
				 in_tenLen(1);
				 unsigned dat=P5_GetStringRun(chu)+1;
				 if(dat>232)dat=1;
				 P5_clearTOP();
				 String_runSetTxt(chu,dat);
				 P5_chonvitri(0,0);
				 P5_sendString_wColorRun(chu,0);
				 HAL_Delay(50);SET_key(0);
			}
			else if(key==2)
			{
				 in_tenXuong(1);
				 unsigned dat=P5_GetStringRun(chu)-1;
				 if(dat==0)dat=232;
				 P5_clearTOP();
				 String_runSetTxt(chu,dat);
				 P5_chonvitri(0,0);
				 P5_sendString_wColorRun(chu,0);
				 HAL_Delay(50);SET_key(0);
			}
			else if(key==5) //sang trai
			{
				if(P5_GetStringRun(chu) != 0)
				{
					if(chu<127)chu++;
					P5_clearTOP();
					P5_chonvitri(0,0);
					P5_sendString_wColorRun(chu,0);
				}
				HAL_Delay(200);SET_key(0);
			}
			else if(key==4) //sang phai
			{
				if(chu!=0)chu--;
				P5_clearTOP();
				P5_chonvitri(0,0);
				P5_sendString_wColorRun(chu,0);
				HAL_Delay(200);SET_key(0);
			}
			else if(key==3) //OK
			{
				 String_SaveData();	 
				 HAL_Delay(300);SET_key(0);
				 caiColor(S{77,164,117,32,99,104,223,0},mauchuChay,0);
				 EEP_write(43,mauchuChay[0]);EEP_write(44,mauchuChay[1]);EEP_write(45,mauchuChay[2]); //save
				 String_runSetALLColor(EEP_read(43),EEP_read(44),EEP_read(45));
				 return;
			}
			else if(key==6) //thoat
			{
				return;
			}
	}
}
void caiFont()
{
	   unsigned char key;
	   int font=font_number;
	   P5_clear();
	   Set_color(0,31,0); 
		 P5_sendnumber_font1(0,0,0,font);
		 P5_sendnumber_font1(13,0,1,font);
	   P5_sendnumber_font1(26,0,2,font);
	   P5_sendnumber_font1(39,0,3,font);
	   in_tenLen(0);in_tenXuong(0);in_OK(0);	
	   HAL_Delay(200);SET_key(0);
	   while(1)
		 {
			  key=GET_key();
			  if(key == 1) //up
				{
					 if(font<4)font++;
					 P5_sendnumber_font1(0,0,0,font);
					 P5_sendnumber_font1(13,0,1,font);
					 P5_sendnumber_font1(26,0,2,font);
					 P5_sendnumber_font1(39,0,3,font);
					 in_tenLen(1);
					 HAL_Delay(200);SET_key(0);
					 in_tenLen(0);in_tenXuong(0);in_OK(0);	
				}
				if(key == 2) //up
				{
					 if(font>0)font--;
					 P5_sendnumber_font1(0,0,0,font);
					 P5_sendnumber_font1(13,0,1,font);
					 P5_sendnumber_font1(26,0,2,font);
					 P5_sendnumber_font1(39,0,3,font);
					 in_tenXuong(1);
					 HAL_Delay(200);SET_key(0);
					 in_tenLen(0);in_tenXuong(0);in_OK(0);	
				}
				if(key == 6)return;
				if(key == 3) //up
				{			 
					 P5_clear();
					 //save
					 EEP_write(40,font);
					 font_number=font;
					 font=font_number2;
					 Set_color(0,31,0); 
					 P5_sendnumber_font2(0,0,0,font);
					 P5_sendnumber_font2(13,0,1,font);
					 P5_sendnumber_font2(26,0,2,font);
					 P5_sendnumber_font2(39,0,3,font);
					 in_tenLen(0);in_tenXuong(0);in_OK(0);	
					 HAL_Delay(200);SET_key(0);
					 while(1)
					 {
						  key=GET_key();
							if(key == 1 || key ==2) //up
							{
								 if(key==1){font=1;in_tenLen(1);}
								 else {font=0;in_tenXuong(1);}
								 P5_sendnumber_font2(0,0,0,font);
								 P5_sendnumber_font2(13,0,1,font);
								 P5_sendnumber_font2(26,0,2,font);
								 P5_sendnumber_font2(39,0,3,font);							 
								 HAL_Delay(200);SET_key(0);
								 in_tenLen(0);in_tenXuong(0);in_OK(0);	
							}
							if(key == 3) //up
							{
								  P5_clear();
								 //save
								 EEP_write(46,font);
								 font_number2=font;
								 HAL_Delay(100);
								 return;
							}
							if(key == 6)return;
					 }
				}
		 }
}

unsigned long time_save_ds;
char kt_save_ds=0,kt_save_cl=0;
void caidat()
{
	 int key;
	 key=GET_key();
	 if(key != 0) // neu co nut nhan dc nhan
	 {
		  if(key == 1) //tang do sang
			{
				 if(GET_dosang() < 490) SET_dosang(GET_dosang()+10);
				 kt_save_ds=1;
				 time_save_ds=HAL_GetTick();
			}
			else if(key == 2) //giam do sang
			{
				 if(GET_dosang() > 10) SET_dosang(GET_dosang()-10);
				 kt_save_ds=1;
				 time_save_ds=HAL_GetTick();
			}
			else if(key == 3) //nut menu - cai dat
			{
				 char caid=0,kt=0;
				 P5_clear();
				 P5_chonvitri(0,0);
				 P5_sendString_wColor(S{67,164,105,32,116,104,210,105,0},0,31,0);			
         P5_chonvitri(0,16);
				 P5_sendString_wColor(S{103,105,97,110,0},0,31,0);						
     		 in_tenLen(0);
				 in_tenXuong(0);
				 in_OK(0);
				 HAL_Delay(300);SET_key(0);
         while(1)
         {
					 key=GET_key();
					 if(key == 2){caid++;if(caid==6)caid=0;kt=1;}
					 else if(key == 1){if(caid==0)caid=5;else caid--;kt=2;}
					 else if(key ==3) //an nut OK
					 {
						 in_OK(1);HAL_Delay(200);	           				 
						 if(caid==0)//cai thoi gian
						 {
							 ghids(2,caiTime(time[2],S{67,164,105,32,103,105,210,0},23,0,CoLor.Hours[0],CoLor.Hours[1],CoLor.Hours[2]));
							 ghids(1,caiTime(time[1],S{67,164,105,32,112,104,214,116,0},59,0,CoLor.Minute[0],CoLor.Minute[1],CoLor.Minute[2]));
							 ghids(0,caiTime(time[0],S{67,164,105,32,103,105,174,121,0},59,0,CoLor.Seconds[0],CoLor.Seconds[1],CoLor.Seconds[2]));
							 ghids(3,caiTime(time[3],S{67,164,105,32,116,104,220,0},7,1,CoLor.Day[0],CoLor.Day[1],CoLor.Day[2]));
							 ghids(4,caiTime(time[4],S{67,164,105,32,110,103,164,121,0},31,1,CoLor.Date[0],CoLor.Date[1],CoLor.Date[2]));
							 ghids(5,caiTime(time[5],S{67,46,84,104,163,110,103,0},12,1,CoLor.Month[0],CoLor.Month[1],CoLor.Month[2]));
							 ghids(6,caiTime(time[6],S{67,164,105,32,110,168,109,0},99,1,CoLor.Year[0],CoLor.Year[1],CoLor.Year[2]));
							 kt=99;
						 }
						 if(caid==1)//cai mau sac
						 {
							 if(caiColor(S{77,164,117,32,71,105,210,0},CoLor.Hours,1))goto thoat;
							 if(caiColor(S{77,46,80,104,214,116,0},CoLor.Minute,1))goto thoat;
							 if(caiColor(S{77,46,71,105,174,121,0},CoLor.Seconds,0))goto thoat;
							 if(caiColor(S{77,164,117,32,84,104,220,0},CoLor.Day,0))goto thoat;
							 if(caiColor(S{77,46,78,103,164,121,0},CoLor.Date,0))goto thoat;
							 if(caiColor(S{84,104,163,110,103,0},CoLor.Month,0))goto thoat;
							 if(caiColor(S{77,46,78,168,109,0},CoLor.Year,0))goto thoat;
							 if(caiColor(S{77,32,78,18,207,0},CoLor.ND,0))goto thoat;
							 thoat:;
							 kt_save_cl=1;
							 time_save_ds=HAL_GetTick();
							 kt=99;
						 }
						 if(caid==2)//cai do sang
						 {
							 EEP_write(47,caiTime(EEP_read(47),S{71,105,210,32,65,117,116,111,0},23,0,14,28,3));
							 kt=99;
						 }
						 if(caid==3)//chu chay
						 {
							  caiChuChay();
							  Getchu(0);
							  kt=99;
						 }
						 if(caid==4)//cai font
						 {
							  caiFont();
							  kt=99;
						 }
						 if(caid==5)//thoat
						 {
							 P5_clear();
							 manhinhchinh(mode_hienthi,1);
							 if(mode_hienthi==2)manhinhchinh(3,1);
							 HAL_Delay(100);
							 SET_key(0);
							 return;
						 }
					 }
					 else if(key ==6) //an nut thoat
					 {
						 P5_clear();
						 manhinhchinh(mode_hienthi,1);
						 if(mode_hienthi==2)manhinhchinh(3,1);
						 HAL_Delay(100);
						 SET_key(0);
						 return;
					 }
					 if(kt)
					 {
						 P5_clear();
				     P5_chonvitri(0,0);
						 if(caid==0)//cai thoi gian
						 {
							  P5_sendString_wColor(S{67,164,105,32,116,104,210,105,0},0,31,0);			
							  P5_chonvitri(0,16);
							  P5_sendString_wColor(S{103,105,97,110,0},0,31,0);					
						 }
						 else if(caid==1)//cai mau sac
						 {
							  P5_sendString_wColor(S{67,164,105,32,109,164,117,0},31,12,1);			
							  P5_chonvitri(0,16);
							  P5_sendString_wColor(S{115,169,99,0},31,12,1);		
						 }
						 else if(caid==2)//cai do sang
						 {
							  P5_sendString_wColor(S{67,164,105,32,180,207,0},11,31,5);			
							  P5_chonvitri(0,16);
							  P5_sendString_wColor(S{115,163,110,103,0},11,31,5);		
						 }
						 else if(caid==3)//cai chu chay
						 {
							  P5_sendString_wColor(S{67,164,105,32,99,104,223,0},1,15,20);			
							  P5_chonvitri(0,16);
							  P5_sendString_wColor(S{99,104,167,121,0},1,15,20);		
						 }
             else if(caid==4)//Cai font chu
						 {
							  P5_sendString_wColor(S{67,164,105,32,102,111,110,116,0},18,31,5);			
             }							 
						 else if(caid==5)//thoat
						 {
							  P5_sendString_wColor(S{84,104,111,163,116,32,33,0},31,0,0);					
						 }		
						 in_tenLen(0);
						 in_tenXuong(0);
						 in_OK(0);
						 if(kt==1)in_tenLen(1);
						 else if(kt==2)in_tenXuong(1);
						 HAL_Delay(200);
						 in_tenLen(0);
						 in_tenXuong(0);
						 in_OK(0);
						 SET_key(0);
						 kt=0;
					 }
         }					 
			}	  
			else if(key == 4 || key==5) //chuyen mode
			{
				 Getchu(0);
				 ef_time=0;
				 P5_clear();
				 mode_hienthi++;if(mode_hienthi==3)mode_hienthi=0;
				 if(mode_hienthi==2)manhinhchinh(3,1);
				 manhinhchinh(mode_hienthi,1);
				 EEP_write(41,mode_hienthi);
				 HAL_Delay(500);
				 SET_key(0);
			}	
			else if(key ==6) //an nut thoat
			{
				P5_clear();
				AUTO_EF=1-AUTO_EF;
				P5_chonvitri(0,0);
				if(AUTO_EF)P5_sendString_wColor(S{65,117,116,111,32,79,78,0},0,31,0);	
				else P5_sendString_wColor(S{65,117,116,111,32,79,70,0},31,0,0);
        HAL_Delay(500);				
				SET_key(0);			
				P5_clear();
				manhinhchinh(mode_hienthi,1);
			  if(mode_hienthi==2)
				  {
						manhinhchinh(3,1);
						Getchu(0);
					}
			}
						 
	 }
}
//-----------dinh nghia cua mode 0 -----------//
#define NUM1_X  0
#define NUM2_X  14
#define NUM3_X  36
#define NUM4_X  50
#define Dau2c_X 28

int mode0_FX=0;
void clear_mode0FX()
{
	 for(int x=0;x<64;x++)
	   for(int y=23;y<30;y++)
	     set_px(x,y,0,0,0);
}
void mode0_inTime(int x,char loai)
{
	 P5_chonvitri(x,23);
	 if(loai==0)
	 {	
    P5_sendnumber_textfont5(S{time[4]/10+1,time[4]%10+1,12,time[5]/10+1,time[5]%10+1,12,3,1,time[6]/10+1,time[6]%10+1,0},S{CoLor.Date[0],CoLor.Date[1],CoLor.Date[2],CoLor.Date[0],CoLor.Date[1],CoLor.Date[2],CoLor.Seconds[0],CoLor.Seconds[1],CoLor.Seconds[2],CoLor.Month[0],CoLor.Month[1],CoLor.Month[2],CoLor.Month[0],CoLor.Month[1],CoLor.Month[2],CoLor.Seconds[0],CoLor.Seconds[1],CoLor.Seconds[2],CoLor.Year[0],CoLor.Year[1],CoLor.Year[2],CoLor.Year[0],CoLor.Year[1],CoLor.Year[2],CoLor.Year[0],CoLor.Year[1],CoLor.Year[2],CoLor.Year[0],CoLor.Year[1],CoLor.Year[2]});
	 }
	 if(loai==1)
	 {
		 P5_sendnumber_textfont5(S{20,18,19,11,ngay_al/10+1,ngay_al%10+1,12,thang_al/10+1,thang_al%10+1,0},S{0,0,0,CoLor.Year[0],CoLor.Year[1],CoLor.Year[2],CoLor.Year[0],CoLor.Year[1],CoLor.Year[2],CoLor.Year[0],CoLor.Year[1],CoLor.Year[2],CoLor.Date[0],CoLor.Date[1],CoLor.Date[2],CoLor.Date[0],CoLor.Date[1],CoLor.Date[2],CoLor.Seconds[0],CoLor.Seconds[1],CoLor.Seconds[2],CoLor.Month[0],CoLor.Month[1],CoLor.Month[2],CoLor.Month[0],CoLor.Month[1],CoLor.Month[2]});
	 }
	 if(loai==2)
	 {
		 char t1,t2;
		 if(time[3] != 1) {t1=13;t2=time[3]+1;}
		 else {t1=15;t2=16;}
		 P5_sendnumber_textfont5(S{20,t1,14,t2,20,nhietdo/10+1,nhietdo%10+1,17,15,0},S{0,0,0,CoLor.Day[0],CoLor.Day[1],CoLor.Day[2],CoLor.Day[0],CoLor.Day[1],CoLor.Day[2],CoLor.Day[0],CoLor.Day[1],CoLor.Day[2],0,0,0,CoLor.ND[0],CoLor.ND[1],CoLor.ND[2],CoLor.ND[0],CoLor.ND[1],CoLor.ND[2],CoLor.ND[0],CoLor.ND[1],CoLor.ND[2],CoLor.ND[0],CoLor.ND[1],CoLor.ND[2]});	 
	 }
}
unsigned long time_mode0_FX;
signed char demlui1=0,demlui2=63,ok_luot=0,cnt_time=0;
void luot()
{
	if(ok_luot && mode_hienthi == 0)
	{
		if(HAL_GetTick() - 10 > time_mode0_FX)
		{
			clear_mode0FX();
			mode0_inTime(demlui1-=2,cnt_time);
			if(demlui1 < -20)
			{
				 if(cnt_time!=2)mode0_inTime(demlui2-=2,cnt_time+1);
				 else mode0_inTime(demlui2-=2,0);
				 if(demlui2<2)ok_luot=0;
			}
			time_mode0_FX = HAL_GetTick();
		}
	}
}

unsigned long time_String_Run;
void manhinhchinh(int mode,char inphut)
{
	 //man hinh 1
	 if(mode==0)
	 {
		 Set_color(CoLor.Hours[0],CoLor.Hours[1],CoLor.Hours[2]);  //in gio
		 P5_sendnumber_font1(NUM1_X,0,time[2]/10,font_number);
		 P5_sendnumber_font1(NUM2_X,0,time[2]%10,font_number);
		 
		 Set_color(CoLor.Minute[0],CoLor.Minute[1],CoLor.Minute[2]);       // in phut
		 P5_sendnumber_font1(NUM3_X,0,time[1]/10,font_number);
		 if(inphut){P5_sendnumber_font1(NUM4_X,0,time[1]%10,font_number);} 
		 mode0_inTime(0,0);
	 }
	//mann hinh 2
	else if(mode==1)
	{
		Clock_Analog_BackGround();
		Clock_Analog(time[2],time[1],time[0],CoLor.Hours);
		P5_chonvitri(32,0);
		P5_sendnumber_textfont5(S{time[4]/10+1,time[4]%10+1,12,time[5]/10+1,time[5]%10+1,0},S{CoLor.Date[0],CoLor.Date[1],CoLor.Date[2],CoLor.Date[0],CoLor.Date[1],CoLor.Date[2],CoLor.Seconds[0],CoLor.Seconds[1],CoLor.Seconds[2],CoLor.Month[0],CoLor.Month[1],CoLor.Month[2],CoLor.Month[0],CoLor.Month[1],CoLor.Month[2]});
    P5_chonvitri(39,8);
		char t1,t2;
		if(time[3] != 1) {t1=13;t2=time[3]+1;}
		else {t1=15;t2=16;}
		P5_sendnumber_textfont5(S{t1,14,t2,0},S{CoLor.Day[0],CoLor.Day[1],CoLor.Day[2],CoLor.Day[0],CoLor.Day[1],CoLor.Day[2],CoLor.Day[0],CoLor.Day[1],CoLor.Day[2]});	 
		P5_chonvitri(36,16);
		P5_sendnumber_textfont5(S{nhietdo/10+1,nhietdo%10+1,17,15,0},S{CoLor.ND[0],CoLor.ND[1],CoLor.ND[2],CoLor.ND[0],CoLor.ND[1],CoLor.ND[2],CoLor.ND[0],CoLor.ND[1],CoLor.ND[2],CoLor.ND[0],CoLor.ND[1],CoLor.ND[2]});	 	
    P5_chonvitri(32,24);
		P5_sendnumber_textfont5(S{ngay_al/10+1,ngay_al%10+1,12,thang_al/10+1,thang_al%10+1,0},S{CoLor.Date[0],CoLor.Date[1],CoLor.Date[2],CoLor.Date[0],CoLor.Date[1],CoLor.Date[2],CoLor.Seconds[0],CoLor.Seconds[1],CoLor.Seconds[2],CoLor.Month[0],CoLor.Month[1],CoLor.Month[2],CoLor.Month[0],CoLor.Month[1],CoLor.Month[2]});
	}
	//man hinh 3
	else if(mode==2)
	{
		if(HAL_GetTick() - time_String_Run > 40)
		{
			P5_StringRun();
			time_String_Run=HAL_GetTick();
		}
	}
	//man hinh 4
	else if(mode==3)
	{
		 Set_color(CoLor.Hours[0],CoLor.Hours[1],CoLor.Hours[2]);  //in gio
		 P5_sendnumber_font2(0,2,time[2]/10,font_number2);
		 P5_sendnumber_font2(10,2,time[2]%10,font_number2);
		 Set_color(CoLor.Day[0],CoLor.Day[1],CoLor.Day[2]);  //in 2c
		 P5_sendnumber_font2(19,2,10,0);
		 Set_color(CoLor.Minute[0],CoLor.Minute[1],CoLor.Minute[2]);       // in phut
		 P5_sendnumber_font2(22,2,time[1]/10,font_number2);
		 P5_sendnumber_font2(32,2,time[1]%10,font_number2);
		 Set_color(CoLor.Day[0],CoLor.Day[1],CoLor.Day[2]);  //in 2c
		 P5_sendnumber_font2(41,2,10,0);
		 if(inphut){
		 Set_color(CoLor.Minute[0],CoLor.Seconds[1],CoLor.Seconds[2]);       // in guay
		 P5_sendnumber_font2(44,2,time[0]/10,font_number2);
		 P5_sendnumber_font2(54,2,time[0]%10,font_number2);}
	}
}

signed char controgiay=0,tcx=0;
void nhapnhaygiay(int mode)
{
	 if(tcx==0)
		 {
			 controgiay++;if(controgiay==4){controgiay=3;tcx=1;}
		 }
	 else
		 {
			 controgiay--;if(controgiay==-1){controgiay=1;tcx=0;}
		 }
	//----------------------------------------------------------//
	 //man hinh 1
	 if(mode==0)
	 {
		  Set_color(CoLor.Seconds[0],CoLor.Seconds[1],CoLor.Seconds[2]);
		  P5_sendnumber_font1(Dau2c_X,0,10+controgiay,0); 
	 }
	//mann hinh 2
	
	//man hinh 3
	 if(mode==2)
	 {
		  Set_color(CoLor.Day[0],CoLor.Day[1],CoLor.Day[2]);
		  P5_sendnumber_font2(19,2,10+controgiay,0); 
		  P5_sendnumber_font2(41,2,10+controgiay,0); 
	 }
}

#define distance_2_num 4
void hieuungchuyentime(int num,int font,int mode)
{
	 if(mode==0)
	 {
		   ef_time--;
		   if(ef_time<=19)
			 {
				 Set_color(CoLor.Minute[0],CoLor.Minute[1],CoLor.Minute[2]);       // in phut
				 lattrang_number_font1(NUM4_X,0,14,20,ef_time,num,font);
			 }	 
			 else lattrang_number_font1(NUM4_X,0,14,20,DELETE,DELETE,DELETE);
	 }
	 if(mode==2)
	 {
		   ef_time--;
		   if(ef_time<=11)
			 {
				 Set_color(CoLor.Seconds[0],CoLor.Seconds[1],CoLor.Seconds[2]);       // in giay
				 if(num%10 != 0)lattrang_number_font2(54,2,9,12,ef_time,num%10,font_number2);
				 else {
					        lattrang_number_font2(44,2,9,12,ef_time,num/10,font_number2);
					        lattrang_number_font2(54,2,9,12,ef_time,num%10,font_number2);
					    }
			 }	 
			 else {
				      if(num%10 != 0)lattrang_number_font2(54,2,9,12,DELETE,DELETE,DELETE);
				      else 
								 {
									 lattrang_number_font2(44,2,9,12,DELETE,DELETE,DELETE);
									 lattrang_number_font2(54,2,9,12,DELETE,DELETE,DELETE);
								 }
				    }
	 }
}
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) 
	{
		 if(htim->Instance==TIM4)ngatquetled();					
		 else if(htim->Instance==TIM3)IR_ngatT();
	}
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) //ngat ngoai exti
{
	   if(GPIO_Pin == IR_PIN) //neu tin hieu den tu chan IR 
          IR_ngatPin(); 
}

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM4_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM3_Init(void);
                                    
void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);
                                

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
unsigned long time1,time2,time3,time4,time5;
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  *
  * @retval None
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  MX_TIM4_Init();
  MX_I2C1_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
	       //lay du lieu
				 Color_init();			 
				 for(int i=0;i<6;i++)for(int i=0;i<6;i++)SET_KEY_IR(i,EEP_read(i));
         HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_4);
			   HAL_TIM_Base_Start_IT(&htim4);
			   __HAL_TIM_SET_COMPARE(&htim2,TIM_CHANNEL_4,GET_dosang());
				 laythoigian();
				 am_lich(time[4],time[5],time[6],&ngay_al,&thang_al);				 
				 P5_SetStringRunY(16);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
      time1=time2=time3=time4=time5=HAL_GetTick();
			manhinhchinh(mode_hienthi,1);		 
			if(mode_hienthi==2)manhinhchinh(3,1);		 
  while (1)
  {
		 
  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
	 caidat();
	 Key_hoclenh();
	 if(HAL_GetTick() - time1 > 400){laythoigian();time1=HAL_GetTick();} //tam 400ms doc thoi gian ve 1 lan
	 if(HAL_GetTick() - time2 > 150) //nhap nhay giay 150ms 1 lan
		 {
			 nhapnhaygiay(mode_hienthi);
			 time2=HAL_GetTick();
		 }
	 luot();
	 if(giaycu != time[0])
	 {
		giaycu=time[0];
		if(mode_hienthi==0)
		{
			P5_veduongngang(1,31,60,0,0,0);		
      P5_veduongngang(1,31,time[0],CoLor.Seconds[0],CoLor.Seconds[1],CoLor.Seconds[2]);	 		 
			if(time[0] % 5 == 0) 
			{
				ok_luot=1;
			  demlui1=0;demlui2=63;
				cnt_time++;if(cnt_time == 3) cnt_time=0;
			}
			if(time[0]==0){manhinhchinh(0,0);ef_time=19+distance_2_num;}
    }		
    else if(mode_hienthi==1)manhinhchinh(1,1);		
		else if(mode_hienthi==2){manhinhchinh(3,0);ef_time=14;}	
	 } 
	 if(ef_time)
		 {
			 if(mode_hienthi==0)if(HAL_GetTick() - time3 > 60){hieuungchuyentime(time[1]%10,font_number,0);time3=HAL_GetTick();}
       if(mode_hienthi==2)if(HAL_GetTick() - time3 > 20){hieuungchuyentime(time[0],font_number,2);time3=HAL_GetTick();}	 
		 }
	 if(mode_hienthi==2)manhinhchinh(2,1);
   if(kt_save_ds || kt_save_cl)
	 {
		  if(HAL_GetTick() - time_save_ds > 3000)
			{
				if(kt_save_ds) //save do sang hien tai
				{
					kt_save_ds=0;
					EEP_write(ADD_dosang,GET_dosang()); //save
				}
				if(kt_save_cl) //save mau sac hien tai
				{
					 kt_save_cl=0;
					 unsigned char *c = CoLor.Hours;
					 for(int i=7;i<31;i++)EEP_write(i,c[i-7]);
				}
			}
	 }
	 if(gio_auto == time[2] && time[1]==0 && time[0]<10)SET_dosang(1); // set do sang ve thap nhat neu gio = gio da cai dat
	 else if(gio_auto == 6 && time[1]==0 && time[0]<10)SET_dosang(100); //do sang ve BT luc 6h
	 if(AUTO_EF)
	 {
		 if(HAL_GetTick() - time5 > 40000)
     {
			 P5_clear();
			 ef_time=0;
			 mode_hienthi++;if(mode_hienthi==3)mode_hienthi=0;
			 manhinhchinh(mode_hienthi,1);
			 if(mode_hienthi==2)
				  {
						manhinhchinh(3,1);
						Getchu(0);
					}
			time5=HAL_GetTick();
     }			 
	 }
  }
  /* USER CODE END 3 */

}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* I2C1 init function */
static void MX_I2C1_Init(void)
{

  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM2 init function */
static void MX_TIM2_Init(void)
{

  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_OC_InitTypeDef sConfigOC;

  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 400;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_LOW;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  HAL_TIM_MspPostInit(&htim2);

}

/* TIM3 init function */
static void MX_TIM3_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 71;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 60000;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/* TIM4 init function */
static void MX_TIM4_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 36000;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 38;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
*/
static void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3 
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7 
                          |GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11 
                          |GPIO_PIN_12, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_10 
                          |GPIO_PIN_12|GPIO_PIN_5, GPIO_PIN_SET);

  /*Configure GPIO pins : PA0 PA1 PA2 PA3 
                           PA4 PA5 PA6 PA7 
                           PA8 PA9 PA10 PA11 
                           PA12 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3 
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7 
                          |GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11 
                          |GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB2 PB10 
                           PB12 PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_10 
                          |GPIO_PIN_12|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB3 */
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PB4 */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
