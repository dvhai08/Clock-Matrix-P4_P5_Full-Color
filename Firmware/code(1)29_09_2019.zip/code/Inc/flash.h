#include "stm32f1xx_hal.h"
#include "stdint.h"
#include "string.h"


//#define DATA_START_ADDRESS 		 	((uint32_t)0x0801EC00)	//Page 123
#define DATA_START_ADDRESS 		 	((uint32_t)0x0801FC00)	//Page 127

void 	Flash_Lock(void);
void 	Flash_Unlock(void);
void 	Flash_Erase(uint32_t addr);
void EEP_write(int add, int data);
uint16_t EEP_read(int add);


//so do bo nho EEPROM

#define ADD_BUTTON_TANG_DO_SANG_EEP   0
#define ADD_BUTTON_GIAM_DO_SANG_EEP   1
#define ADD_BUTTON_MENU_EEP           2
#define ADD_BUTTON_UP_EEP             3
#define ADD_BUTTON_DOWN_EEP           4
#define ADD_BUTTON_THOAT_EEP          5
#define ADD_dosang                    42


